# 品牌沟通助手：腾讯云 EdgeOne 托管版

本目录从原部署包独立复制。原始 brand-assistant-prod 与服务器部署包保留。

- 项目：soochowhackathon261101
- 项目 ID：<edgeone-project-id>
- 正式域名：https://soochowhackathon261101.noiamist.com
- 加速区域：全球可用区（不含中国大陆）
- 运行方式：Next.js 页面与 API 由 EdgeOne Makers 托管。
- 任务数据保存在当前浏览器的 localStorage，不跨设备同步。

## 本地运行

运行 npm ci，然后运行 npm run dev。
API Key 由使用者自行配置。不要提交 .env.local，不要将 Key 放进 NEXT_PUBLIC_ 变量。

## 构建与更新

运行 npx --yes edgeone makers build。
构建结果位于 .edgeone/。上传包应保留 <项目文件夹>/.edgeone/ 目录结构，并在项目文件夹下放置 edgeone.json。
生产环境变量在腾讯云项目设置中维护，改动后需要重新部署。

edgeone.json 配置香港云函数和 120 秒执行上限。原 API 路由仍保留 60 秒的 Next.js maxDuration；实际执行情况以部署结果与调用验证为准。
构建包、检查状态及域名启用进度见上一级 部署包/EdgeOne部署记录.json。正式交付使用上方自有域名。
