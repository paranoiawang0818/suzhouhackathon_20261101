import { z } from "zod";
import { askJSON } from "@/lib/llm";
import { presetClarify } from "@/lib/fallback";
import type { NeedKey, RequestInput } from "@/lib/types";

export const maxDuration = 60;

const NeedSchema = z.object({ value: z.string(), clear: z.boolean(), ask: z.string() });
const Schema = z.object({
  needs: z.object({ info: NeedSchema, goal: NeedSchema, deliver: NeedSchema }),
  subQuestions: z.array(z.string()),
});

const SYSTEM = `你是药企内部“医学问询协作平台”的需求澄清助手，服务对象是一线销售 / 代表。
目标：在交给医学部之前，帮一线人员把“自己到底要什么”说清楚。不是让销售去追问医生，而是帮销售想清楚三件事：
- info 想得到什么信息：需要医学部提供哪些事实或数据。
- goal 想解决什么问题：这次沟通要帮医生解决什么、背后的场景（例如是否考虑给某类患者用药）。
- deliver 希望医学部给什么：答复的深度和形式，是否需要说明证据覆盖不到的地方。

规则：
- 每一项写出你的理解 value。能从医生原话、用途、交付要求和销售填写的内容中明确得出时 clear=true，ask 留空。
- 不能明确时 clear=false，value 写你的推测并以“（推测）”开头，ask 写一个具体问题请销售补充，可附 1–2 个选项示例。
- 销售已经填写的项视为明确，value 直接采用其内容（可略作整理，不改变含义），clear=true。
- 再根据三项内容，把需求拆成 2–4 个医学部可以逐一回答的子问题 subQuestions，忠实于原意，不扩大、不缩小范围。
- 你不回答医学问题本身，也不得把未知信息填成事实。
- 全部使用简体中文。`;

export async function POST(req: Request) {
  const { request, userNeeds = {} } = (await req.json()) as {
    request: RequestInput;
    userNeeds?: Partial<Record<NeedKey, string>>;
  };
  const filled = (k: NeedKey) => userNeeds[k]?.trim() || "（未填写）";
  const user = `产品/议题：${request.product}
医生原话：${request.original}
用途：${request.purpose}
沟通对象：${request.audience}
交付要求：${request.delivery}

销售填写的需求：
- 想得到什么信息：${filled("info")}
- 想解决什么问题：${filled("goal")}
- 希望医学部给什么：${filled("deliver")}`;
  try {
    const out = await askJSON(SYSTEM, user, Schema);
    // 销售填写过的项以销售为准
    for (const k of ["info", "goal", "deliver"] as NeedKey[]) {
      if (userNeeds[k]?.trim()) out.needs[k] = { ...out.needs[k], clear: true, ask: "" };
    }
    return Response.json({ ...out, source: "ai" });
  } catch (e) {
    return Response.json({ ...presetClarify(request, userNeeds), source: "preset", error: String(e) });
  }
}
