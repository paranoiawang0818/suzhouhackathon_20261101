import { z } from "zod";
import { askJSON } from "@/lib/llm";
import { presetEvidence } from "@/lib/fallback";
import { SOURCES } from "@/lib/sources";
import type { KnowledgeEntry, Needs, SourceDoc, SubQuestion } from "@/lib/types";

export const maxDuration = 60;

const Schema = z.object({
  analysis: z.array(
    z.object({
      subQId: z.string(),
      answerability: z.enum(["direct", "partial", "insufficient"]),
      approach: z.string(),
    }),
  ),
  links: z.array(z.object({ subQId: z.string(), sourceId: z.string(), reason: z.string() })),
  kbLinks: z.array(z.object({ subQId: z.string(), kbId: z.string(), reason: z.string() })),
  gaps: z.array(z.object({ subQId: z.string(), gap: z.string() })),
});

const SYSTEM = `你是药企医学部的资料分析助手。医学人员拿到问题前，你先做准备工作，帮他们节省查资料的时间。
输入：一线的需求说明、若干子问题、企业论文/资料库（sources）、企业问题库（kb，医学部已确认过的历史答复）。
对每个子问题：
1. analysis：判断现有资料能否回答——direct（资料可直接回答）/ partial（只能回答一部分）/ insufficient（资料不足）；approach 用 1–2 句话写出“建议怎么答”：引用哪类资料、注意什么边界或口径差异。这是给医学人员的线索，不要写成最终答复，不要下诊疗结论。
2. links：从 sources 中选出真正相关的资料（每题最多 4 条），reason 一句话说明它提供了什么。
3. kbLinks：如果 kb 中有相关的已确认历史答复，列出并说明可以参考哪部分；适用性仍需医学人员判断。
4. gaps：资料覆盖不到的地方（例如所问人群不在研究范围内、没有直接对比研究），写明资料覆盖到哪里。
规则：只能引用输入中存在的 id；不得编造资料或数据；数据不一致的资料（如论文与新闻稿）都列出并提示差异；使用简体中文。`;

export async function POST(req: Request) {
  const {
    subQuestions,
    extraSources = [],
    kb = [],
    needs,
  } = (await req.json()) as {
    subQuestions: SubQuestion[];
    extraSources?: SourceDoc[];
    kb?: KnowledgeEntry[];
    needs?: Needs;
  };
  const pool = [...SOURCES, ...extraSources];
  const corpus = pool.map(({ id, title, kind, date, location, quote, zh, scope }) => ({ id, title, kind, date, location, quote, zh, scope }));
  const kbCorpus = kb.map((k) => ({ id: k.id, title: k.title, items: k.items.map((i) => ({ q: i.q, a: i.a })) }));
  const user = `一线需求：
- 想得到什么信息：${needs?.info.value ?? "（无）"}
- 想解决什么问题：${needs?.goal.value ?? "（无）"}
- 希望医学部给什么：${needs?.deliver.value ?? "（无）"}

子问题：
${subQuestions.map((q) => `${q.id}: ${q.text}`).join("\n")}

资料库 sources：
${JSON.stringify(corpus, null, 1)}

问题库 kb：
${JSON.stringify(kbCorpus, null, 1)}`;
  try {
    const out = await askJSON(SYSTEM, user, Schema);
    const ids = new Set(pool.map((s) => s.id));
    const kbIds = new Set(kb.map((k) => k.id));
    const qids = new Set(subQuestions.map((q) => q.id));
    return Response.json({
      analysis: out.analysis.filter((a) => qids.has(a.subQId)),
      links: out.links.filter((l) => ids.has(l.sourceId) && qids.has(l.subQId)),
      kbLinks: out.kbLinks.filter((l) => kbIds.has(l.kbId) && qids.has(l.subQId)),
      gaps: out.gaps.filter((g) => qids.has(g.subQId)),
      source: "ai",
    });
  } catch (e) {
    return Response.json({ ...presetEvidence(subQuestions, pool, kb), source: "preset", error: String(e) });
  }
}
