import "server-only";
import Anthropic from "@anthropic-ai/sdk";
import { betaZodOutputFormat } from "@anthropic-ai/sdk/helpers/beta/zod";
import type { z } from "zod";

const MODEL = process.env.LLM_MODEL || "claude-opus-5-5";

export function llmConfigured() {
  return Boolean(process.env.ANTHROPIC_API_KEY || process.env.ANTHROPIC_AUTH_TOKEN);
}

let client: Anthropic | null = null;
function getClient() {
  if (!client) client = new Anthropic({ timeout: 55_000, maxRetries: 1 });
  return client;
}

/** 调用 Claude 并按 zod schema 返回结构化结果；失败时抛错，由调用方降级为预设结果 */
export async function askJSON<T extends z.ZodType>(
  system: string,
  user: string,
  schema: T,
): Promise<z.infer<T>> {
  if (!llmConfigured()) throw new Error("LLM 未配置");
  const res = await getClient().beta.messages.parse({
    model: MODEL,
    max_tokens: 8000,
    system,
    messages: [{ role: "user", content: user }],
    output_config: { effort: "low", format: betaZodOutputFormat(schema) },
    betas: ["server-side-fallback-2026-07-01"],
    fallbacks: "default",
  });
  if (res.stop_reason === "refusal") throw new Error("模型拒绝了该请求");
  if (!res.parsed_output) throw new Error("模型输出无法解析");
  return res.parsed_output as z.infer<T>;
}
