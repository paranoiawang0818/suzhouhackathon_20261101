import type { ExperienceEntry, KnowledgeEntry, Task } from "./types";

const d = (daysAgo: number, h = 10) => {
  const x = new Date();
  x.setDate(x.getDate() - daysAgo);
  x.setHours(h, 0, 0, 0);
  return x.toISOString();
};
const day = (offset: number) => {
  const x = new Date();
  x.setDate(x.getDate() + offset);
  return x.toISOString().slice(0, 10);
};

const SALES = "销售 · 王晓";
const MED = "医学部 · 李医生";

/** 历史任务：已走完全流程，用于演示知识库复用 */
const historyTask: Task = {
  id: "T-hist01",
  title: "GLORY-1 研究的主要终点是什么？减重效果怎么样？",
  createdAt: d(12),
  updatedAt: d(9),
  submitter: SALES,
  deadline: day(-9),
  stage: "done",
  request: {
    product: "玛仕度肽（信尔美）",
    original: "GLORY-1 研究的主要终点是什么？减重效果怎么样？",
    purpose: "回复医生学术问询",
    audience: "内分泌科主任",
    delivery: "一页沟通卡",
  },
  reqVersions: [
    {
      v: 1,
      at: d(12),
      supplement: "",
      subQuestions: [
        { id: "q1", text: "GLORY-1 研究的主要终点是什么？" },
        { id: "q2", text: "GLORY-1 研究中玛仕度肽的减重幅度是多少？" },
      ],
      unknowns: [],
      confirmed: true,
    },
  ],
  evidence: {
    links: [
      { id: "e1", subQId: "q1", sourceId: "S4", reason: "给出了主要终点定义", status: "adopted", addedBy: "ai" },
      { id: "e2", subQId: "q2", sourceId: "S5", reason: "第 32 周体重变化", status: "adopted", addedBy: "ai" },
      { id: "e3", subQId: "q2", sourceId: "S6", reason: "第 48 周体重变化", status: "adopted", addedBy: "ai" },
      { id: "e4", subQId: "q2", sourceId: "S11", reason: "新闻稿数据与论文不同", status: "excluded", addedBy: "ai" },
    ],
    gaps: [],
    scope: "预置公开资料",
    source: "preset",
    at: d(12),
  },
  manualSources: [],
  draft: [],
  draftUsedPreset: false,
  checks: [],
  answers: [
    {
      v: 1,
      at: d(10),
      author: MED,
      confirmedBy: MED,
      reqV: 1,
      usedPreset: false,
      items: [
        {
          subQId: "q1",
          text: "主要终点为第 32 周体重相对基线变化百分比，以及体重下降≥5% 的受试者比例（治疗策略估计目标）。",
          cited: ["S4"],
          insufficient: false,
        },
        {
          subQId: "q2",
          text: "第 32 周：4 mg −10.09%、6 mg −12.55%、安慰剂 +0.45%；第 48 周：4 mg −11.00%、6 mg −14.01%、安慰剂 +0.30%。以论文发表数据为准，企业新闻稿数字口径不同，不混用。",
          cited: ["S5", "S6"],
          insufficient: false,
        },
      ],
    },
  ],
  materials: [],
  deliveries: [],
  log: [
    { at: d(12), actor: SALES, action: "提交需求并确认问题清单 v1" },
    { at: d(10), actor: MED, action: "确认医学答复 v1，归档至企业知识库" },
    { at: d(9), actor: SALES, action: "交付沟通卡，医生反馈：已解决" },
  ],
};

/** 历史任务 2：安全性问询，已确认归档，用于演示“问题库”复用 */
const historyTask2: Task = {
  ...historyTask,
  id: "T-hist02",
  title: "玛仕度肽的不良反应主要是什么？停药的人多吗？",
  createdAt: d(20),
  updatedAt: d(17),
  deadline: day(-17),
  request: { ...historyTask.request, original: "玛仕度肽的不良反应主要是什么？停药的人多吗？", audience: "全科医生" },
  reqVersions: [
    {
      v: 1,
      at: d(20),
      supplement: "",
      subQuestions: [
        { id: "q1", text: "GLORY-1 研究中最常见的不良反应是什么？严重程度如何？" },
        { id: "q2", text: "GLORY-1 研究中因不良事件停药的比例是多少？" },
      ],
      unknowns: [],
      confirmed: true,
    },
  ],
  evidence: undefined,
  answers: [
    {
      v: 1,
      at: d(18),
      author: MED,
      confirmedBy: MED,
      reqV: 1,
      usedPreset: false,
      items: [
        { subQId: "q1", text: "最常见的不良事件为胃肠道反应，多为轻至中度（GLORY-1，18–75 岁研究人群，48 周）。", cited: ["S7"], insufficient: false },
        { subQId: "q2", text: "因不良事件停药比例：4 mg 组 1.5%，6 mg 组 0.5%，安慰剂组 1.0%。", cited: ["S7"], insufficient: false },
      ],
    },
  ],
  log: [
    { at: d(20), actor: SALES, action: "提交需求并确认问题清单 v1" },
    { at: d(18), actor: MED, action: "确认医学答复 v1，归档至企业知识库" },
  ],
};

/** 进行中的任务：停在医学部环节，用于展示医学部视角的任务列表 */
const inProgressTask: Task = {
  id: "T-prog01",
  title: "玛仕度肽常见的不良反应有哪些？因为副作用停药的人多吗？",
  createdAt: d(1, 15),
  updatedAt: d(1, 16),
  submitter: SALES,
  deadline: day(2),
  stage: "answer",
  request: {
    product: "玛仕度肽（信尔美）",
    original: "玛仕度肽常见的不良反应有哪些？因为副作用停药的人多吗？",
    purpose: "回复医生学术问询",
    audience: "全科医生",
    delivery: "一页沟通卡",
  },
  reqVersions: [
    {
      v: 1,
      at: d(1, 15),
      supplement: "医生主要关心胃肠道反应",
      subQuestions: [
        { id: "q1", text: "GLORY-1 研究中最常见的不良反应是什么？严重程度如何？" },
        { id: "q2", text: "GLORY-1 研究中因不良事件停药的比例是多少？" },
      ],
      unknowns: [],
      confirmed: true,
    },
  ],
  evidence: {
    links: [
      { id: "e1", subQId: "q1", sourceId: "S7", reason: "描述了最常见不良事件及严重程度", status: "candidate", addedBy: "ai" },
      { id: "e2", subQId: "q2", sourceId: "S7", reason: "给出了各组因不良事件停药比例", status: "candidate", addedBy: "ai" },
    ],
    gaps: [],
    analysis: [
      { subQId: "q1", answerability: "direct", approach: "引用安全性结果：最常见不良事件的类型与严重程度。" },
      { subQId: "q2", answerability: "direct", approach: "引用各组因不良事件停药的比例，注明观察期为 48 周。" },
    ],
    kbLinks: [
      { subQId: "q1", kbId: "K-hist02", reason: "已确认答复中有「最常见的不良反应」，可参考" },
      { subQId: "q2", kbId: "K-hist02", reason: "已确认答复中有「因不良事件停药的比例」，可参考" },
    ],
    scope: "预置公开资料 + 企业问题库",
    source: "preset",
    at: d(1, 16),
  },
  manualSources: [],
  draft: [],
  draftUsedPreset: false,
  checks: [],
  answers: [],
  materials: [],
  deliveries: [],
  log: [
    { at: d(1, 15), actor: SALES, action: "提交需求并确认问题清单 v1" },
    { at: d(1, 16), actor: "AI", action: "完成证据匹配，交医学部" },
  ],
};

export const SEED_TASKS: Task[] = [inProgressTask, historyTask, historyTask2];

export const SEED_KNOWLEDGE: KnowledgeEntry[] = [
  {
    id: "K-hist01",
    taskId: "T-hist01",
    answerV: 1,
    title: "GLORY-1 主要终点与减重幅度",
    question: historyTask.request.original,
    context: "内分泌科主任学术问询；产品：玛仕度肽（信尔美）",
    items: historyTask.reqVersions[0].subQuestions.map((q) => {
      const a = historyTask.answers[0].items.find((i) => i.subQId === q.id)!;
      return { q: q.text, a: a.text, refs: a.cited, insufficient: a.insufficient };
    }),
    confirmedBy: MED,
    confirmedAt: d(10),
    status: "有效",
  },
  {
    id: "K-hist02",
    taskId: "T-hist02",
    answerV: 1,
    title: "GLORY-1 不良反应与停药比例",
    question: historyTask2.request.original,
    context: "全科医生学术问询；产品：玛仕度肽（信尔美）",
    items: historyTask2.reqVersions[0].subQuestions.map((q) => {
      const a = historyTask2.answers[0].items.find((i) => i.subQId === q.id)!;
      return { q: q.text, a: a.text, refs: a.cited, insufficient: a.insufficient };
    }),
    confirmedBy: MED,
    confirmedAt: d(18),
    status: "有效",
  },
];

export const SEED_EXPERIENCE: ExperienceEntry[] = [
  {
    id: "X-1",
    taskId: "T-hist01",
    kind: "经验案例",
    scope: "团队",
    title: "主任关心数据口径，先说明“论文数据为准”",
    scene: "内分泌科主任问减重效果，手里有新闻稿和论文两个数字",
    action: "沟通卡只放论文数据，并口头说明新闻稿口径不同",
    result: "医生认可，反馈已解决",
    author: SALES,
    at: d(9),
  },
  {
    id: "X-2",
    kind: "表达偏好",
    scope: "个人",
    title: "沟通卡偏好：先结论后数据",
    scene: "给临床医生的一页卡",
    action: "每个问题先用一句话给结论，再列关键数字和出处；语气专业克制，不用营销词",
    result: "",
    author: SALES,
    at: d(20),
  },
];
