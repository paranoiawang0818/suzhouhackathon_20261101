"use client";

/**
 * 自动演示模式（带字幕）：从首页 /?autoplay=1 或首页按钮启动，按 Esc 退出。
 * 用虚拟光标真实点击页面元素（data-demo 标记），保证演示的就是产品本身。
 */
import { useRouter } from "next/navigation";
import { AnimatePresence, motion } from "motion/react";
import { useEffect, useRef } from "react";
import { create } from "zustand";
import { useStore } from "@/lib/store";

interface DirectorState {
  active: boolean;
  chapter: string;
  caption: string;
  card: { title: string; lines: string[]; kicker?: string } | null;
  curtain: boolean;
  cursor: { x: number; y: number } | null;
  clicks: number;
}

export const useDirector = create<DirectorState>()(() => ({
  active: false,
  chapter: "",
  caption: "",
  card: null,
  curtain: false,
  cursor: null,
  clicks: 0,
}));

declare global {
  interface Window {
    __demoDone?: boolean;
  }
}

class Stop extends Error {}

export function startDirector() {
  useDirector.setState({ active: true, caption: "", chapter: "", card: null, cursor: null });
}

export function Director() {
  const router = useRouter();
  const active = useDirector((s) => s.active);
  const running = useRef(false);

  // URL 参数启动
  useEffect(() => {
    if (new URLSearchParams(window.location.search).get("autoplay") === "1") startDirector();
  }, []);

  useEffect(() => {
    if (!active || running.current) return;
    running.current = true;
    window.__demoDone = false;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && useDirector.setState({ active: false });
    window.addEventListener("keydown", onKey);
    runScript(router.push)
      .catch((e) => {
        if (!(e instanceof Stop)) console.error("[demo]", e);
      })
      .finally(async () => {
        running.current = false;
        window.__demoDone = true;
        window.removeEventListener("keydown", onKey);
        await sleep(1200);
        useDirector.setState({ active: false, caption: "", card: null, curtain: false, cursor: null, chapter: "" });
      });
  }, [active, router.push]);

  return <DirectorOverlay />;
}

/* ---------------- 演示脚本 ---------------- */

const GOAL = "帮医生判断 75 岁以上的老年肥胖患者能不能用，医生最担心安全性";
const DELIVER = "书面要点即可：研究事实 + 明确说明证据覆盖不到的人群，附出处";
const INSUFFICIENT = "现有资料不足以回答：GLORY-1 仅纳入 18–75 岁成人，未纳入 75 岁以上人群，无法据此判断该人群的疗效与安全性。";

async function runScript(push: (href: string) => void) {
  const d = useDirector.setState;
  const st = useStore.getState();
  st.reset();
  st.setGuide(false);
  push("/");
  window.scrollTo({ top: 0 });

  // 片头
  await card("药企一线 · 每天都会遇到", "医生问了一个专业问题", ["“这个研究纳入的是多大年龄的人？", "我那边老年患者挺多，能用吗？”", "一线代表答不了，只能转给医学部。"], 6500);
  await card("问题出在三个地方", "一来一回，效率和合规都受影响", ["需求没说清 → 医学部反复来回确认", "资料靠人工翻 → 查证耗时", "答复漏了一问 → 回到一线才发现"], 7000);
  await card("我们的方案", "品牌沟通助手", ["AI 整理问题与证据，发现遗漏", "医学部完成专业答复，并对结果负责", "销售把专业内容说清楚，经验持续沉淀"], 6500);
  d({ curtain: false });
  await wait(600);

  // 首页
  chapter("产品首页");
  await say("这是给药企一线代表和医学部使用的医学问询协作平台。", 4200);
  await scrollTo("flow");
  await say("一条任务、六个环节，每一步由谁负责都写得清清楚楚。", 4600);
  await scrollTo("roles");
  await say("AI 只做整理和检查，专业结论始终由医学部负责。", 4200);
  window.scrollTo({ top: 0, behavior: "smooth" });
  await wait(900);
  await click("start");

  // 1 说清需求
  chapter("① 说清需求");
  say("销售把医生原话提交进来，AI 先帮一线梳理：到底要什么。");
  await waitFor("needs", 20000);
  await point("needs");
  await say("三个问题：想得到什么信息、想解决什么问题、希望医学部给什么。", 4600);
  await point("need-goal");
  await say("“想解决什么问题”和“希望医学部给什么”还没说清，AI 给出了追问。", 4400);
  say("不一定再去问医生——一线人员把自己的需求写清楚就行。");
  await type("need-goal", GOAL, 55);
  await type("need-deliver", DELIVER, 55);
  await click("reclarify");
  say("按补充重新整理，三个问题全部说清，生成需求 v2。");
  await wait(800);
  await waitFor("confirm-req:enabled", 20000);
  await wait(900);
  await point("needs");
  await say("说清了才往下走：医学部拿到的是明确的需求，而不是一句转述。", 4200);
  await click("confirm-req");

  // 2 AI 分析
  chapter("② AI 分析并调取资料");
  say("AI 先判断每个问题能不能答、怎么答，再从论文库和企业问题库调出资料。");
  await waitFor("switch-role", 20000);
  await wait(600);
  await click("step-evidence");
  await point("analysis");
  await say("预判结果：两题资料可直接回答，第 3 题只能回答一部分。", 4400);
  await point("gap");
  await say("每题附上解答思路、原文证据和医学部确认过的历史答复；资料覆盖不到的如实标出缺口。", 5200);
  await click("step-answer");
  await click("switch-role");

  // 3 医学部答复
  chapter("③ 医学部答复");
  await say("医学部拿到的是一份准备好的资料包，而不是从零开始查。", 4000);
  await click("insert-evidence");
  await say("原文要点可以一键插入答复——但结论仍由医学人员撰写，并对结果负责。", 4600);
  await click("load-preset");
  await say("这里载入一份演示样稿，故意把第 3 题留空。", 3400);
  await click("submit-check");

  // 4 对照审核
  chapter("④ AI 对照原问题审核");
  say("AI 对照最初提交的问题，逐题检查有没有遗漏或答偏。");
  await waitFor("coverage", 20000);
  await wait(600);
  await point("coverage");
  await say("第 3 题没有回应，被标了出来——这类遗漏以前要回到一线才会发现。", 4800);
  say("医学人员写明“现有资料不足以回答”及原因——这也是一种明确的处理结果。");
  await type("missing-input", INSUFFICIENT, 28);
  await wait(1800);
  await say("答复修改后，旧的检查结果自动作废，需要重新检查。", 3000);
  await click("recheck");
  await waitFor("confirm-answer:enabled", 20000);
  await wait(800);
  await say("每一题都有处理结果，医学人员确认答复，同时归档企业知识库。", 4200);
  await click("confirm-answer");
  await wait(1800);

  // 5 销售制作材料
  chapter("⑤ 销售制作品牌材料");
  await click("switch-role");
  await say("回到销售。企业模板加上个人表达偏好，一键生成沟通卡。", 3800);
  await click("gen-card");
  await waitFor("card", 20000);
  await wait(700);
  await point("card");
  await say("沟通卡和医学原文左右对照，标明依据的答复版本，不冒用医学审核。", 5200);
  await click("deliver");

  // 6 反馈
  chapter("⑥ 记录医生反馈");
  await say("交付之后记录医生反馈，绑定到这一次交付的版本。", 3600);
  await click("fb-已解决");
  await click("save-fb");
  await wait(900);
  window.scrollTo({ top: 0, behavior: "smooth" });
  await say("任务完成：用时、版本、沉淀的知识，一目了然。", 4200);

  // 知识库
  chapter("知识沉淀与复用");
  say("");
  push("/kb");
  await waitFor("kb-search", 10000);
  await wait(600);
  await type("kb-search", "年龄", 160);
  await say("确认过的答复进入企业知识库。下次遇到类似问询，直接就能找到参考。", 5200);

  // 片尾
  chapter("");
  d({ cursor: null, caption: "" });
  await card("品牌沟通助手", "让医学部答得准，让销售说得清", ["AI 整理问题与证据，发现遗漏", "医学部完成专业答复，并对结果负责", "确认过的答复与一线经验，留给下一次"], 7000, true);
}

/* ---------------- 工具函数 ---------------- */

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

async function wait(ms: number) {
  const step = 100;
  for (let t = 0; t < ms; t += step) {
    if (!useDirector.getState().active) throw new Stop();
    await sleep(step);
  }
}

function chapter(c: string) {
  useDirector.setState({ chapter: c });
}

/** 显示字幕；传入 ms 时等待阅读时间 */
async function say(text: string, ms = 0) {
  useDirector.setState({ caption: text });
  if (ms) await wait(ms);
}

/** 全屏卡片；卡片之间保持深色幕布，避免露出底下的页面 */
async function card(kicker: string, title: string, lines: string[], ms: number, hold = false) {
  useDirector.setState({ curtain: true, card: { kicker, title, lines }, caption: "" });
  await wait(ms);
  if (hold) return;
  useDirector.setState({ card: null });
  await wait(500);
}

function find(sel: string): HTMLElement | null {
  const [name, cond] = sel.split(":");
  const els = Array.from(document.querySelectorAll<HTMLElement>(`[data-demo="${name}"]`)).filter((e) => e.offsetParent !== null);
  const el = els[0] ?? null;
  if (el && cond === "enabled" && (el as HTMLButtonElement).disabled) return null;
  return el;
}

async function waitFor(sel: string, timeout = 12000) {
  for (let t = 0; t < timeout; t += 100) {
    const el = find(sel);
    if (el && !useDirector.getState().card && !document.querySelector("[data-ai-overlay]")) return el;
    await wait(100);
  }
  throw new Error(`demo: 找不到 ${sel}`);
}

async function scrollTo(sel: string) {
  const el = await waitFor(sel);
  window.scrollTo({ top: el.getBoundingClientRect().top + window.scrollY - 84, behavior: "smooth" });
  await wait(900);
}

/** 光标移到元素上 */
async function point(sel: string) {
  const el = await waitFor(sel);
  const r0 = el.getBoundingClientRect();
  if (r0.top < 70 || r0.bottom > window.innerHeight - 90) {
    el.scrollIntoView({ behavior: "smooth", block: "center" });
    await wait(700);
  }
  const r = el.getBoundingClientRect();
  useDirector.setState({ cursor: { x: r.left + Math.min(r.width / 2, 160), y: r.top + Math.min(r.height / 2, 40) } });
  await wait(750);
  return el;
}

async function click(sel: string) {
  const el = await point(sel);
  useDirector.setState((s) => ({ clicks: s.clicks + 1 }));
  await wait(180);
  el.click();
  await wait(450);
}

/** 逐字输入，触发 React 受控组件更新 */
async function type(sel: string, text: string, speed = 70) {
  const el = (await point(sel)) as HTMLInputElement | HTMLTextAreaElement;
  el.focus();
  const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
  const setter = Object.getOwnPropertyDescriptor(proto, "value")!.set!;
  for (let i = 1; i <= text.length; i++) {
    setter.call(el, text.slice(0, i));
    el.dispatchEvent(new Event("input", { bubbles: true }));
    await wait(speed);
  }
  await wait(400);
}

/* ---------------- 叠加层：字幕 / 光标 / 片头片尾 ---------------- */

function DirectorOverlay() {
  const { active, caption, chapter, card, curtain, cursor, clicks } = useDirector();
  if (!active) return null;
  return (
    <>
      {/* 字幕 */}
      <AnimatePresence mode="wait">
        {caption && !card && (
          <motion.div
            key={caption}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.25 }}
            className="pointer-events-none fixed bottom-[88px] left-1/2 z-[70] max-w-[80vw] -translate-x-1/2 rounded-xl bg-black/80 px-7 py-3.5 text-center text-[22px] font-medium leading-snug text-white shadow-2xl"
          >
            {chapter && <div className="mb-1 text-[13px] font-semibold tracking-widest text-[#8fb3ff]">{chapter}</div>}
            {caption}
          </motion.div>
        )}
      </AnimatePresence>

      {/* 虚拟光标 */}
      {cursor && !card && (
        <motion.div
          className="pointer-events-none fixed left-0 top-0 z-[80]"
          animate={{ x: cursor.x, y: cursor.y }}
          transition={{ type: "spring", stiffness: 120, damping: 20 }}
        >
          <motion.span
            key={clicks}
            className="absolute -left-5 -top-5 h-10 w-10 rounded-full bg-brand/40"
            initial={{ scale: 0.2, opacity: 0.9 }}
            animate={{ scale: 1.6, opacity: 0 }}
            transition={{ duration: 0.6 }}
          />
          <svg width="26" height="26" viewBox="0 0 24 24" className="drop-shadow-lg">
            <path d="M3 2l7.5 19 2.6-7.9L21 10.5z" fill="#0f1d3a" stroke="#fff" strokeWidth="1.6" strokeLinejoin="round" />
          </svg>
        </motion.div>
      )}

      {/* 片头片尾：深色幕布 + 卡片内容 */}
      <AnimatePresence>
        {curtain && (
          <motion.div
            key="curtain"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.6 }}
            className="fixed inset-0 z-[89] bg-navy"
          >
            <div
              className="pointer-events-none absolute inset-0 opacity-[0.07]"
              style={{ backgroundImage: "radial-gradient(#fff 1px, transparent 1px)", backgroundSize: "22px 22px" }}
            />
          </motion.div>
        )}
      </AnimatePresence>
      <AnimatePresence>
        {card && (
          <motion.div
            key={card.title}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.45 }}
            className="fixed inset-0 z-[90] flex items-center justify-center text-white"
          >
            <div className="relative max-w-3xl px-10 text-center">
              {card.kicker && (
                <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="text-sm tracking-[0.3em] text-[#8fb3ff]">
                  {card.kicker}
                </motion.div>
              )}
              <motion.div
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.15 }}
                className="mt-4 text-[46px] font-bold leading-tight"
              >
                {card.title}
              </motion.div>
              <div className="mt-8 space-y-3">
                {card.lines.map((l, i) => (
                  <motion.div
                    key={l}
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.6 + i * 0.55 }}
                    className="text-[22px] text-white/85"
                  >
                    {l}
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
