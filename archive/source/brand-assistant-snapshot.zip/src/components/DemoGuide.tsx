"use client";

import { usePathname } from "next/navigation";
import { AnimatePresence, motion } from "motion/react";
import { useState } from "react";
import { useHydrated, useStore } from "@/lib/store";
import { checkAllHandled, checkIsStale, latestCheck } from "@/lib/flow";
import type { Role, Task } from "@/lib/types";
import { useDirector } from "./Director";

interface Scene {
  no: number;
  title: string;
  todo: string;
  say: string;
  copy?: string[];
}

const TOTAL = 9;
const GOAL = "帮医生判断 75 岁以上的老年肥胖患者能不能用，医生最担心安全性";
const DELIVER = "书面要点即可：研究事实 + 明确说明证据覆盖不到的人群，附出处";

function sceneFor(path: string, t: Task | undefined, role: Role): Scene | null {
  if (path === "/")
    return { no: 1, title: "开场", todo: "介绍一句话价值和六个环节，然后点「一键开始演示」。", say: "AI 做整理和检查，专业结论由医学部负责。" };
  if (path === "/new") return { no: 1, title: "提交需求", todo: "点一个示例问题填入，再点「提交，让 AI 整理问题」。", say: "销售可以先提交不完整的信息。" };
  if (path === "/tasks") return { no: 1, title: "任务看板", todo: "点开一条任务，或回首页「一键开始演示」。", say: "负责人、下一节点、截止时间贯穿全程。" };
  if (path === "/kb")
    return {
      no: 9,
      title: "知识复用",
      todo: "搜索「年龄」找到刚确认的答复；回首页再演示一次，第 2 步会出现「企业知识库线索」。",
      say: "确认过的答复留给下一次；复用时适用性仍由医学人员判断。",
    };
  if (!t) return null;
  const supplemented = t.reqVersions.length > 1;
  switch (t.stage) {
    case "clarify":
      return supplemented
        ? { no: 3, title: "确认需求", todo: "三个问题都说清了。核对问题清单，点「需求已说清，交给 AI 分析」。", say: "说清了才往下走，医学部拿到的是明确的需求。" }
        : {
            no: 2,
            title: "说清需求",
            todo: "AI 标出「想解决什么问题」「希望医学部给什么」没说清。把下面两句分别填进对应输入框，点「按补充重新整理」。",
            say: "不一定去问医生，关键是一线自己想清楚要什么。",
            copy: [GOAL, DELIVER],
          };
    case "evidence":
      return { no: 3, title: "AI 分析", todo: "等待 AI 预判问题并调取资料。", say: "先判断能不能答、怎么答，再调出论文和历史答复。" };
    case "answer":
      return role === "sales"
        ? { no: 4, title: "看 AI 的准备", todo: "左侧点「AI 分析并调取资料」看预判；指出问题库命中和「资料缺口」，再点「切换为医学部继续」。", say: "医学部拿到的不是一个问题，而是一份准备好的资料包。" }
        : {
            no: 4,
            title: "医学部答复",
            todo: "可点「插入要点」引用原文；演示时点「载入模拟医学答复」（Q3 故意留空），再点底部「提交 AI 对照原问题审核」。",
            say: "要点一键引用，结论由医学人员撰写并负责。",
          };
    case "check": {
      const c = latestCheck(t);
      if (checkIsStale(t, c)) return { no: 5, title: "重新检查", todo: "答复已修改，点「重新检查」。", say: "答复一改，旧的检查结果自动过期。" };
      if (!checkAllHandled(c))
        return {
          no: 5,
          title: "处理遗漏",
          todo: "AI 标出 Q3 可能遗漏。在表格里写明「资料不足」的原因，再点「重新检查」。",
          say: "完整性检查不评价对错，只看有没有回应。",
          copy: ["现有资料不足以回答：GLORY-1 仅纳入 18–75 岁成人，未纳入 75 岁以上人群。"],
        };
      return { no: 6, title: "确认答复", todo: "每题都有处理结果了，点「医学人员确认答复」。", say: "确认即归档企业知识库，医学部对结果负责。" };
    }
    case "material":
      return role === "medical"
        ? { no: 7, title: "交给销售", todo: "点「切换为销售继续」。", say: "销售拿到的是医学部确认过的版本。" }
        : t.materials.length
          ? { no: 7, title: "交付材料", todo: "左右对照原文，可「导出图片」，再点「确认使用已审内容并交付」。", say: "材料标明依据的答复版本，不冒用医学审核状态。" }
          : { no: 7, title: "制作材料", todo: "个人偏好已自动带入，点「用模板生成沟通卡」。", say: "企业模板 + 个人表达风格。" };
    case "feedback":
      return { no: 8, title: "记录反馈", todo: "选「部分解决」并保存，再在下方沉淀一条经验。", say: "反馈绑定具体交付版本。" };
    case "done":
      return { no: 9, title: "收尾", todo: "点「查看知识库」，展示刚沉淀的答复。", say: "每完成一次问询，下一次就更快。" };
  }
}

export function DemoGuide() {
  const hydrated = useHydrated();
  const path = usePathname();
  const role = useStore((s) => s.role);
  const open = useStore((s) => s.guide);
  const setOpen = useStore((s) => s.setGuide);
  const id = path.startsWith("/task/") ? path.split("/")[2] : "";
  const t = useStore((s) => s.tasks.find((x) => x.id === id));
  const [copied, setCopied] = useState("");
  const directing = useDirector((s) => s.active);
  if (!hydrated || directing) return null;
  const sc = sceneFor(path, t, role);
  if (!sc) return null;

  if (!open)
    return (
      <button
        data-demo-guide
        onClick={() => setOpen(true)}
        className="fixed bottom-5 left-5 z-40 rounded-full bg-navy px-4 py-2 text-sm text-white shadow-lg hover:bg-navy/90"
      >
        演示向导 {sc.no}/{TOTAL}
      </button>
    );

  return (
    <motion.div
      data-demo-guide
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="fixed bottom-5 left-5 z-40 w-[272px] overflow-hidden rounded-2xl bg-navy text-white shadow-2xl ring-1 ring-white/10"
    >
      <div className="flex items-center gap-2 px-4 pt-3">
        <span className="text-[11px] tracking-widest text-white/50">演示向导</span>
        <div className="flex flex-1 gap-0.5">
          {Array.from({ length: TOTAL }, (_, i) => (
            <span key={i} className={`h-1 flex-1 rounded-full ${i < sc.no ? "bg-[#8fb3ff]" : "bg-white/15"}`} />
          ))}
        </div>
        <button onClick={() => setOpen(false)} className="text-xs text-white/50 hover:text-white">
          收起
        </button>
      </div>
      <AnimatePresence mode="wait">
        <motion.div
          key={`${sc.no}-${sc.title}`}
          initial={{ opacity: 0, x: 10 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -10 }}
          transition={{ duration: 0.18 }}
          className="px-4 pb-4 pt-2"
        >
          <div className="font-semibold">
            {sc.no}/{TOTAL} · {sc.title}
          </div>
          <p className="mt-1.5 text-[13px] leading-5 text-white/85">{sc.todo}</p>
          {sc.copy?.map((c) => (
            <button
              key={c}
              onClick={() => {
                navigator.clipboard.writeText(c);
                setCopied(c);
                setTimeout(() => setCopied(""), 1500);
              }}
              className="mt-2 w-full rounded-lg bg-white/10 px-3 py-2 text-left text-xs text-white/90 hover:bg-white/15"
            >
              <span className="text-white/50">{copied === c ? "已复制 ✓" : "点击复制："}</span>
              {c}
            </button>
          ))}
          <div className="mt-3 border-t border-white/10 pt-2 text-xs text-white/55">
            <span className="text-[#8fb3ff]">讲解：</span>
            {sc.say}
          </div>
        </motion.div>
      </AnimatePresence>
    </motion.div>
  );
}
